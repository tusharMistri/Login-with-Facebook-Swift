//
//  ViewController.swift
//  FacebookIntegration
//
//  Created by Tushar on 09/01/18.
//  Copyright © 2018 tushar. All rights reserved.
//

import UIKit

import FBSDKLoginKit


class ViewController: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()

//        let myLoginButton = UIButton(type: .custom)
//        myLoginButton.backgroundColor = UIColor.darkGray
//        myLoginButton.frame = CGRect(x: 0, y: 0, width: 180, height: 40)
//        myLoginButton.center = view.center;
//        myLoginButton.setTitle("My Login Button", for: .normal)
//        
//        // Handle clicks on the button
//        myLoginButton.addTarget(self, action: #selector(loginButtonClicked), for: .touchDragInside)
//        
//        // Add the button to the view
//        view.addSubview(myLoginButton)
    }
    
    
    @IBAction func FacebookLogin(_ sender: UIButton)
    {
        self.loginButtonClicked()
    }
    
    
    func loginButtonClicked()
    {
        let loginManager = FBSDKLoginManager()
        
        loginManager.logIn(withReadPermissions: ["email"], from: self) { (result, error) in
            if (error == nil)
            {
                let fbloginresult : FBSDKLoginManagerLoginResult = result!
                if fbloginresult.grantedPermissions != nil {
                    if(fbloginresult.grantedPermissions.contains("email"))
                    {
                        self.getFBUserData()
                        //                        fbLoginManager.logOut()
                    }
                }
            }
        }
    }
    
    
    func getFBUserData()
    {
        if((FBSDKAccessToken.current()) != nil)
        {
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).start(completionHandler: { (connection, result, error) -> Void in
                if (error == nil){
                    //                    self.dict = result as! [String : AnyObject]
                    print(result!)
                    //                    print(self.dict)
                }
            })
        }
    }
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

